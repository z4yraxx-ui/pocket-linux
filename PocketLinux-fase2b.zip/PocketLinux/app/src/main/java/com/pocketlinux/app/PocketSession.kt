package com.pocketlinux.app

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.io.IOException

/**
 * Estado único do app (vive enquanto o processo viver): instalação do Debian
 * e o shell em execução. A interface só observa os StateFlows daqui.
 */
object PocketSession {
    private const val MAX_LINES = 3000

    internal lateinit var paths: PocketPaths
        private set
    private lateinit var appContext: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var installJob: Job? = null

    private val runner by lazy { DebianRunner(paths) }

    private val _installState = MutableStateFlow<InstallState>(InstallState.NotInstalled)
    val installState: StateFlow<InstallState> = _installState.asStateFlow()

    private val _terminalLines = MutableStateFlow<List<String>>(emptyList())
    val terminalLines: StateFlow<List<String>> = _terminalLines.asStateFlow()

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private val _updateState = MutableStateFlow<UpdateState>(UpdateState.Idle)
    val updateState: StateFlow<UpdateState> = _updateState.asStateFlow()

    /** Verdadeiro enquanto algo precisa manter o processo vivo: o shell ou uma atualização. */
    val isBusy: Flow<Boolean> = combine(_isRunning, _updateState) { running, update ->
        running || update.isBusy()
    }

    /** Vira verdadeiro se o PRoot só funcionou sem seccomp; comandos avulsos seguem o mesmo modo. */
    @Volatile
    private var noSeccompNeeded = false

    @Volatile
    private var userStopped = false

    fun init(context: Context) {
        if (::paths.isInitialized) return
        appContext = context.applicationContext
        paths = PocketPaths(context)
        refresh()
    }

    fun refresh() {
        if (installJob?.isActive == true) return
        _installState.value =
            if (paths.installedMarker.exists() && paths.rootfsDir.isDirectory) InstallState.Installed
            else InstallState.NotInstalled
    }

    // ---------- instalação ----------

    fun startInstall() {
        if (installJob?.isActive == true) return
        _installState.value = InstallState.Working("Preparando")
        installJob = scope.launch {
            try {
                RootfsInstaller(paths).install { _installState.value = it }
                _installState.value = InstallState.Installed
            } catch (e: CancellationException) {
                _installState.value = InstallState.NotInstalled
                throw e
            } catch (e: InstallException) {
                _installState.value = InstallState.Failed(e.message ?: "Erro desconhecido")
            } catch (e: IOException) {
                _installState.value = InstallState.Failed("Falha de rede ou de disco: ${e.message}")
            } catch (e: Exception) {
                _installState.value = InstallState.Failed("${e.javaClass.simpleName}: ${e.message}")
            }
        }
    }

    fun cancelInstall() {
        installJob?.cancel()
    }

    fun uninstall() {
        if (installJob?.isActive == true) return
        stopShell()
        _installState.value = InstallState.Working("Apagando")
        installJob = scope.launch {
            try {
                deleteTree(paths.baseDir)
                _installState.value = InstallState.NotInstalled
            } catch (e: Exception) {
                _installState.value = InstallState.Failed("Não consegui apagar: ${e.message}")
            }
        }
    }

    // ---------- shell ----------

    private val lock = Any()
    private val doneLines = ArrayDeque<String>()
    private val partial = StringBuilder()
    private var pendingCr = false
    private val outChannel = Channel<String>(Channel.UNLIMITED)
    private var consumerJob: Job? = null

    private val ansi = Regex("\u001B\\[[0-9;?]*[ -/]*[@-~]|\u001B\\][^\u0007]*\u0007")

    private fun ensureConsumer() {
        if (consumerJob?.isActive == true) return
        consumerJob = scope.launch {
            for (first in outChannel) {
                synchronized(lock) { append(first) }
                delay(30) // junta várias saídas seguidas numa atualização só
                synchronized(lock) {
                    while (true) {
                        val next = outChannel.tryReceive().getOrNull() ?: break
                        append(next)
                    }
                    publish()
                }
            }
        }
    }

    private fun append(chunk: String) {
        for (ch in ansi.replace(chunk, "")) {
            when {
                ch == '\n' -> {
                    pendingCr = false
                    doneLines.addLast(partial.toString())
                    partial.setLength(0)
                    if (doneLines.size > MAX_LINES) doneLines.removeFirst()
                }

                ch == '\r' -> pendingCr = true

                else -> {
                    if (pendingCr) { // \r sozinho = volta ao começo da linha (barras de progresso)
                        partial.setLength(0)
                        pendingCr = false
                    }
                    when {
                        ch == '\t' -> partial.append("    ")
                        ch.code < 0x20 -> Unit
                        else -> partial.append(ch)
                    }
                }
            }
        }
    }

    private fun publish() {
        val list = ArrayList<String>(doneLines.size + 1)
        list.addAll(doneLines)
        if (partial.isNotEmpty()) list.add(partial.toString())
        _terminalLines.value = list
    }

    fun startShell() {
        if (_isRunning.value) return
        if (_installState.value !is InstallState.Installed) return
        userStopped = false
        // Não apaga a tela se uma atualização está escrevendo nela.
        if (!_updateState.value.isBusy()) {
            synchronized(lock) {
                doneLines.clear()
                partial.setLength(0)
                pendingCr = false
                publish()
            }
        }
        launchShell(noSeccomp = false)
        startBackgroundService()
    }

    /**
     * Liga o serviço em primeiro plano que segura o processo com o app fechado.
     * Ele se desliga sozinho quando [isRunning] vira falso. Se o Android recusar
     * (app fora de primeiro plano), o Debian segue rodando só enquanto o app viver.
     */
    private fun startBackgroundService() {
        try {
            ContextCompat.startForegroundService(appContext, Intent(appContext, PocketService::class.java))
        } catch (e: Exception) {
            outChannel.trySend("[Aviso: não consegui ligar o serviço em segundo plano: ${e.message}]\n")
        }
    }

    private fun launchShell(noSeccomp: Boolean) {
        ensureConsumer()
        if (noSeccomp) noSeccompNeeded = true
        _isRunning.value = true
        val startedAt = SystemClock.elapsedRealtime()
        try {
            runner.start(
                noSeccomp = noSeccomp,
                onOutput = { outChannel.trySend(it) },
                onExit = { code ->
                    val quickFailure = SystemClock.elapsedRealtime() - startedAt < 4000
                    if (code != 0 && quickFailure && !noSeccomp && !userStopped) {
                        outChannel.trySend("\n[O PRoot fechou logo (código $code). Tentando de novo sem seccomp...]\n")
                        launchShell(noSeccomp = true)
                    } else {
                        outChannel.trySend("\n[sessão encerrada, código $code]\n")
                        _isRunning.value = false
                    }
                }
            )
        } catch (e: IOException) {
            outChannel.trySend(
                "[Não consegui executar o PRoot: ${e.message}]\n" +
                    "[Caminho: ${paths.prootBin.path}]\n"
            )
            _isRunning.value = false
        }
    }

    /** Mostra o comando digitado (o shell sem terminal real não devolve o eco) e envia ao Debian. */
    fun send(line: String) {
        if (!_isRunning.value) return
        outChannel.trySend(line + "\n")
        scope.launch { runner.send(line + "\n") }
    }

    fun stopShell() {
        userStopped = true
        runner.stop()
    }

    // ---------- atualizar ----------

    private fun say(text: String) {
        outChannel.trySend(text)
    }

    /** Passo 1: atualiza a lista de pacotes e conta quantos têm atualização (ainda não instala nada). */
    fun checkUpdates() {
        if (_installState.value !is InstallState.Installed) return
        if (_updateState.value.isBusy()) return
        ensureConsumer()
        _updateState.value = UpdateState.Checking
        startBackgroundService()
        scope.launch {
            try {
                say("\n[Atualizar] Buscando a lista de pacotes...\n")
                val code = runner.exec("apt-get update 2>&1", noSeccompNeeded) { say(it + "\n") }
                if (code != 0) {
                    _updateState.value =
                        UpdateState.Failed("O apt update terminou com erro (código $code). Veja o terminal.")
                    return@launch
                }
                var count = 0
                runner.exec("apt-get -s upgrade 2>&1", noSeccompNeeded) { line ->
                    if (line.startsWith("Inst ")) count++
                }
                if (count == 0) {
                    say("[Atualizar] Tudo atualizado.\n")
                    _updateState.value = UpdateState.UpToDate
                } else {
                    say("[Atualizar] $count pacote(s) com atualização.\n")
                    _updateState.value = UpdateState.Available(count)
                }
            } catch (e: Exception) {
                _updateState.value = UpdateState.Failed("Não consegui rodar o apt: ${e.message}")
            }
        }
    }

    /** Passo 2: instala as atualizações achadas no passo 1. */
    fun applyUpdates() {
        if (_updateState.value !is UpdateState.Available) return
        ensureConsumer()
        _updateState.value = UpdateState.Upgrading
        startBackgroundService()
        scope.launch {
            try {
                say("\n[Atualizar] Instalando as atualizações...\n")
                val code = runner.exec(
                    "apt-get upgrade -y -o Dpkg::Options::=--force-confold 2>&1",
                    noSeccompNeeded
                ) { say(it + "\n") }
                if (code == 0) {
                    say("[Atualizar] Concluído.\n")
                    _updateState.value = UpdateState.Done
                } else {
                    _updateState.value =
                        UpdateState.Failed("A atualização terminou com erro (código $code). Veja o terminal.")
                }
            } catch (e: Exception) {
                _updateState.value = UpdateState.Failed("Não consegui rodar o apt: ${e.message}")
            }
        }
    }

    fun dismissUpdate() {
        if (!_updateState.value.isBusy()) _updateState.value = UpdateState.Idle
    }

    // ---------- diagnóstico e armazenamento ----------

    fun hasPhoneStorageAccess(): Boolean = paths.hasPhoneStorageAccess()

    /** Últimas linhas do terminal, para o relatório de diagnóstico. */
    fun lastTerminalLines(count: Int): List<String> = _terminalLines.value.takeLast(count)
}
