package com.pocketlinux.app

import java.io.IOException
import java.io.OutputStream
import kotlin.concurrent.thread

/** Roda um shell do Debian dentro do PRoot e conecta a entrada/saída dele ao app. */
class DebianRunner(private val paths: PocketPaths) {

    @Volatile
    private var process: Process? = null

    @Volatile
    private var stdin: OutputStream? = null

    /** Processo de um comando avulso (atualização), separado do shell interativo. */
    @Volatile
    private var execProcess: Process? = null

    /** PRoot com tudo configurado, faltando só o programa a executar. */
    private fun baseCommand(): List<String> {
        // Pasta do celular (ou pasta própria do app, se não houver permissão) vira ~/Android.
        // Precisa existir no Debian antes de montar.
        paths.sharedMount.mkdirs()
        val shared = paths.sharedHostDir()
        return listOf(
            paths.prootBin.path,
            "-r", paths.rootfsDir.path,
            "-0", // finge ser root (apt, dpkg e sudo funcionam)
            "--link2symlink", // o Android proíbe hard links: o PRoot troca por links simbólicos
            "--kill-on-exit",
            "-b", "/dev",
            "-b", "/proc",
            "-b", "/sys",
            "-b", "${shared.path}:/root/Android",
            "-w", "/root"
        )
    }

    private fun environment(noSeccomp: Boolean): Map<String, String> {
        val env = linkedMapOf(
            "PROOT_LOADER" to paths.prootLoader.path,
            "PROOT_TMP_DIR" to paths.prootTmpDir.path,
            "HOME" to "/root",
            "USER" to "root",
            "LOGNAME" to "root",
            "SHELL" to "/bin/bash",
            "PATH" to "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            "TERM" to "dumb",
            "LANG" to "pt_BR.UTF-8",
            "DEBIAN_FRONTEND" to "noninteractive"
        )
        if (noSeccomp) env["PROOT_NO_SECCOMP"] = "1"
        return env
    }

    private fun newBuilder(command: List<String>, noSeccomp: Boolean): ProcessBuilder {
        paths.prootTmpDir.mkdirs()
        val builder = ProcessBuilder(command)
        builder.redirectErrorStream(true)
        builder.directory(paths.baseDir)
        builder.environment().apply {
            clear()
            putAll(environment(noSeccomp))
        }
        return builder
    }

    /** Lança IOException se o PRoot não puder ser executado. */
    @Throws(IOException::class)
    fun start(noSeccomp: Boolean, onOutput: (String) -> Unit, onExit: (Int) -> Unit) {
        val p = newBuilder(baseCommand() + listOf("/bin/bash", "-i"), noSeccomp).start()
        process = p
        stdin = p.outputStream

        thread(name = "proot-output", isDaemon = true) {
            val buf = CharArray(4096)
            try {
                p.inputStream.reader(Charsets.UTF_8).use { reader ->
                    while (true) {
                        val n = reader.read(buf)
                        if (n < 0) break
                        onOutput(String(buf, 0, n))
                    }
                }
            } catch (e: IOException) {
                // processo morreu: segue para o waitFor
            }
            val code = try {
                p.waitFor()
            } catch (e: InterruptedException) {
                -1
            }
            if (process === p) {
                process = null
                stdin = null
            }
            onExit(code)
        }
    }

    /**
     * Roda um comando avulso no Debian (não interativo) e entrega a saída linha a linha.
     * Bloqueia até terminar: chamar fora da thread principal. Devolve o código de saída.
     */
    @Throws(IOException::class)
    fun exec(script: String, noSeccomp: Boolean, onLine: (String) -> Unit): Int {
        val p = newBuilder(baseCommand() + listOf("/bin/bash", "-c", script), noSeccomp).start()
        execProcess = p
        try {
            p.outputStream.close() // nada vai ser digitado: evita o apt esperar entrada
        } catch (e: IOException) {
            // já fechou
        }
        try {
            p.inputStream.bufferedReader(Charsets.UTF_8).forEachLine(onLine)
        } catch (e: IOException) {
            // processo morreu: segue para o waitFor
        }
        val code = try {
            p.waitFor()
        } catch (e: InterruptedException) {
            -1
        }
        if (execProcess === p) execProcess = null
        return code
    }

    /** Chamar fora da thread principal: escrever num pipe pode bloquear. */
    fun send(text: String) {
        val out = stdin ?: return
        try {
            synchronized(out) {
                out.write(text.toByteArray(Charsets.UTF_8))
                out.flush()
            }
        } catch (e: IOException) {
            // o shell já encerrou
        }
    }

    fun stop() {
        process?.destroyForcibly()
        execProcess?.destroyForcibly()
    }
}
