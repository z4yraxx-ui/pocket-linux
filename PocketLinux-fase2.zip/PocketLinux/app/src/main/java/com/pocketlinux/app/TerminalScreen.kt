package com.pocketlinux.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val TermBg = Color(0xFF0B0F1A)
private val TermFg = Color(0xFFD7E3F4)

@Composable
fun TerminalScreen(onBack: () -> Unit) {
    BackHandler(onBack = onBack)

    val lines by PocketSession.terminalLines.collectAsState()
    val running by PocketSession.isRunning.collectAsState()
    val listState = rememberLazyListState()
    val clipboard = LocalClipboardManager.current
    var input by remember { mutableStateOf("") }

    // Abrir a tela já liga o Debian (não faz nada se já estiver rodando ou não instalado).
    LaunchedEffect(Unit) { PocketSession.startShell() }

    // Sempre mostra o final da saída.
    LaunchedEffect(lines) {
        if (lines.isNotEmpty()) listState.scrollToItem(lines.lastIndex)
    }

    fun submit() {
        if (input.isBlank()) return
        PocketSession.send(input)
        input = ""
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar", tint = Mint)
            }
            Text("Terminal Debian", modifier = Modifier.padding(end = 8.dp))
            StatusPill(if (running) "Em execução" else "Parado")
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { clipboard.setText(AnnotatedString(lines.joinToString("\n"))) }) {
                Text("Copiar", color = Mint)
            }
            if (running) {
                TextButton(onClick = { PocketSession.stopShell() }) { Text("Encerrar", color = Mint) }
            } else {
                TextButton(onClick = { PocketSession.startShell() }) { Text("Iniciar", color = Mint) }
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(TermBg)
                .padding(10.dp)
        ) {
            items(lines.size) { i ->
                Text(
                    text = lines[i].ifEmpty { " " },
                    color = TermFg,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                enabled = running,
                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 14.sp),
                placeholder = { Text("comando", fontFamily = FontFamily.Monospace) },
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.None,
                    keyboardType = KeyboardType.Ascii,
                    imeAction = ImeAction.Send
                ),
                keyboardActions = KeyboardActions(onSend = { submit() })
            )
            IconButton(onClick = { submit() }, enabled = running) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Enviar", tint = Mint)
            }
        }
    }
}
