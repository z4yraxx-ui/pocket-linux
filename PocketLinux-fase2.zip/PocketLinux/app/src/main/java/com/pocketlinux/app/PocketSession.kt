package com.pocketlinux.app

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.IOException

/**
 * Estado único do app (vive enquanto o processo viver): instalação do Debian
 * e o shell em execução. A interface só observa os StateFlows daqui.
 */
object PocketSession {
    private const val MAX_LINES = 3000

    private lateinit var paths: PocketPaths
    private lateinit var appContext: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var installJob: Job? = null

    private val runner by lazy { DebianRunner(paths) }

    private val _installState = MutableStateFlow<InstallState>(InstallState.NotInstalled)
    val installState: StateFlow<InstallState> = _installState.asStateFlow()

    private val _terminalLines = MutableStateFlow<List<String>>(emptyList())
    val terminalLines: StateFlow<List<String>> = _terminalLines.asStateFlow()

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    @Volatile
    private var userStopped = false

    fun init(context: Context) {
        if (::paths.isInitialized) return
        appContext = context.applicationContext
        paths = PocketPaths(context)
        refresh()
    }

    fun refresh() {
        if (installJob?.isActive == true) return
        _installState.value =
            if (paths.installedMarker.exists() && paths.rootfsDir.isDirectory) InstallState.Installed
            else InstallState.NotInstalled
    }

    // ---------- instalação ----------

    fun startInstall() {
        if (installJob?.isActive == true) return
        _installState.value = InstallState.Working("Preparando")
        installJob = scope.launch {
            try {
                RootfsInstaller(paths).install { _installState.value = it }
                _installState.value = InstallState.Installed
            } catch (e: CancellationException) {
                _installState.value = InstallState.NotInstalled
                throw e
            } catch (e: InstallException) {
                _installState.value = InstallState.Failed(e.message ?: "Erro desconhecido")
            } catch (e: IOException) {
                _installState.value = InstallState.Failed("Falha de rede ou de disco: ${e.message}")
            } catch (e: Exception) {
                _installState.value = InstallState.Failed("${e.javaClass.simpleName}: ${e.message}")
            }
        }
    }

    fun cancelInstall() {
        installJob?.cancel()
    }

    fun uninstall() {
        if (installJob?.isActive == true) return
        stopShell()
        _installState.value = InstallState.Working("Apagando")
        installJob = scope.launch {
            try {
                deleteTree(paths.baseDir)
                _installState.value = InstallState.NotInstalled
            } catch (e: Exception) {
                _installState.value = InstallState.Failed("Não consegui apagar: ${e.message}")
            }
        }
    }

    // ---------- shell ----------

    private val lock = Any()
    private val doneLines = ArrayDeque<String>()
    private val partial = StringBuilder()
    private var pendingCr = false
    private val outChannel = Channel<String>(Channel.UNLIMITED)
    private var consumerJob: Job? = null

    private val ansi = Regex("\u001B\\[[0-9;?]*[ -/]*[@-~]|\u001B\\][^\u0007]*\u0007")

    private fun ensureConsumer() {
        if (consumerJob?.isActive == true) return
        consumerJob = scope.launch {
            for (first in outChannel) {
                synchronized(lock) { append(first) }
                delay(30) // junta várias saídas seguidas numa atualização só
                synchronized(lock) {
                    while (true) {
                        val next = outChannel.tryReceive().getOrNull() ?: break
                        append(next)
                    }
                    publish()
                }
            }
        }
    }

    private fun append(chunk: String) {
        for (ch in ansi.replace(chunk, "")) {
            when {
                ch == '\n' -> {
                    pendingCr = false
                    doneLines.addLast(partial.toString())
                    partial.setLength(0)
                    if (doneLines.size > MAX_LINES) doneLines.removeFirst()
                }

                ch == '\r' -> pendingCr = true

                else -> {
                    if (pendingCr) { // \r sozinho = volta ao começo da linha (barras de progresso)
                        partial.setLength(0)
                        pendingCr = false
                    }
                    when {
                        ch == '\t' -> partial.append("    ")
                        ch.code < 0x20 -> Unit
                        else -> partial.append(ch)
                    }
                }
            }
        }
    }

    private fun publish() {
        val list = ArrayList<String>(doneLines.size + 1)
        list.addAll(doneLines)
        if (partial.isNotEmpty()) list.add(partial.toString())
        _terminalLines.value = list
    }

    fun startShell() {
        if (_isRunning.value) return
        if (_installState.value !is InstallState.Installed) return
        userStopped = false
        synchronized(lock) {
            doneLines.clear()
            partial.setLength(0)
            pendingCr = false
            publish()
        }
        launchShell(noSeccomp = false)
        startBackgroundService()
    }

    /**
     * Liga o serviço em primeiro plano que segura o processo com o app fechado.
     * Ele se desliga sozinho quando [isRunning] vira falso. Se o Android recusar
     * (app fora de primeiro plano), o Debian segue rodando só enquanto o app viver.
     */
    private fun startBackgroundService() {
        try {
            ContextCompat.startForegroundService(appContext, Intent(appContext, PocketService::class.java))
        } catch (e: Exception) {
            outChannel.trySend("[Aviso: não consegui ligar o serviço em segundo plano: ${e.message}]\n")
        }
    }

    private fun launchShell(noSeccomp: Boolean) {
        ensureConsumer()
        _isRunning.value = true
        val startedAt = SystemClock.elapsedRealtime()
        try {
            runner.start(
                noSeccomp = noSeccomp,
                onOutput = { outChannel.trySend(it) },
                onExit = { code ->
                    val quickFailure = SystemClock.elapsedRealtime() - startedAt < 4000
                    if (code != 0 && quickFailure && !noSeccomp && !userStopped) {
                        outChannel.trySend("\n[O PRoot fechou logo (código $code). Tentando de novo sem seccomp...]\n")
                        launchShell(noSeccomp = true)
                    } else {
                        outChannel.trySend("\n[sessão encerrada, código $code]\n")
                        _isRunning.value = false
                    }
                }
            )
        } catch (e: IOException) {
            outChannel.trySend(
                "[Não consegui executar o PRoot: ${e.message}]\n" +
                    "[Caminho: ${paths.prootBin.path}]\n"
            )
            _isRunning.value = false
        }
    }

    /** Mostra o comando digitado (o shell sem terminal real não devolve o eco) e envia ao Debian. */
    fun send(line: String) {
        if (!_isRunning.value) return
        outChannel.trySend(line + "\n")
        scope.launch { runner.send(line + "\n") }
    }

    fun stopShell() {
        userStopped = true
        runner.stop()
    }
}
