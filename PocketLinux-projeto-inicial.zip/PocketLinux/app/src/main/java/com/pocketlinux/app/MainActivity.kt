package com.pocketlinux.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Monitor
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101522)
private val Panel = Color(0xFF1B2433)
private val Mint = Color(0xFF77E0B5)
private val Muted = Color(0xFF9BA9BC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PocketLinuxApp() }
    }
}

@Composable
fun PocketLinuxApp() {
    var isInstalled by remember { mutableStateOf(false) }
    var isRunning by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink,
            surface = Panel,
            primary = Mint,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Ink
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("PocketLinux", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                        Text("Seu ambiente Linux no Android", color = Muted, fontSize = 13.sp)
                    }
                    Surface(color = Panel, shape = RoundedCornerShape(14.dp)) {
                        Text("PL", modifier = Modifier.padding(14.dp), color = Mint, fontWeight = FontWeight.Bold)
                    }
                }

                Surface(
                    color = Panel,
                    shape = RoundedCornerShape(22.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("DEBIAN", color = Mint, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Spacer(Modifier.weight(1f))
                            StatusPill(if (isRunning) "Em execução" else if (isInstalled) "Instalado" else "Não instalado")
                        }
                        Text("Debian ARM64 + LXQt", fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            "O ambiente Linux será instalado no armazenamento privado do aplicativo.",
                            color = Muted,
                            fontSize = 13.sp
                        )
                        Button(
                            onClick = { isInstalled = true },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !isInstalled
                        ) {
                            Text(if (isInstalled) "Debian preparado (protótipo)" else "Preparar instalação")
                        }
                        OutlinedButton(
                            onClick = { isRunning = !isRunning },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = isInstalled
                        ) {
                            Text(if (isRunning) "Encerrar ambiente" else "Iniciar Debian")
                        }
                        Text(
                            "Protótipo visual: os botões ainda não baixam nem executam o Debian.",
                            color = Muted,
                            fontSize = 11.sp
                        )
                    }
                }

                Text("Acesso rápido", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    QuickTile("Desktop", Icons.Default.Monitor, Modifier.weight(1f))
                    QuickTile("Arquivos", Icons.Default.Folder, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    QuickTile("Terminal", Icons.Default.Terminal, Modifier.weight(1f))
                    QuickTile("Configurações", Icons.Default.Settings, Modifier.weight(1f))
                }

                Spacer(Modifier.weight(1f))
                Text("PocketLinux 0.1.0 • primeira prévia", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun StatusPill(label: String) {
    Surface(color = Color(0xFF263B3A), shape = RoundedCornerShape(50)) {
        Text(label, color = Mint, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
    }
}

@Composable
private fun QuickTile(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = modifier) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.Start,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(icon, contentDescription = null, tint = Mint)
            Text(label, fontWeight = FontWeight.Medium, fontSize = 13.sp)
        }
    }
}
