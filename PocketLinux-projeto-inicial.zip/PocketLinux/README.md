# PocketLinux

Primeiro protótipo Android do PocketLinux.

## Estado desta versão

Esta é uma **prévia visual** em Kotlin + Jetpack Compose. A interface permite explorar o fluxo visual, mas ainda não instala nem executa Debian. Os módulos PRoot, rootfs Debian ARM64 e servidor gráfico X11 ainda serão implementados.

## Compilar no GitHub Actions

1. Crie um repositório GitHub chamado `PocketLinux`.
2. Envie todo o conteúdo desta pasta para a branch `main`.
3. Abra a aba **Actions**.
4. Se necessário, habilite workflows para o repositório.
5. Execute **Build PocketLinux APK** em **Run workflow**.
6. Ao terminar, abra a execução e baixe o artefato `PocketLinux-debug`.

O APK ficará em `app/build/outputs/apk/debug/app-debug.apk` dentro do ambiente de compilação e também será publicado como artefato da execução.

## Requisitos técnicos

- Android Studio / Gradle
- JDK 17
- Android SDK 35
- Min SDK 26 (Android 8.0)
